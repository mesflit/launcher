package com.mesflit.baslatici;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends Activity {
	
	private HashMap<String, Object> Map = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> map = new ArrayList<>();
	
	private LinearLayout linear1;
	private GridView gridview1;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		gridview1 = findViewById(R.id.gridview1);
	}
	
	private void initializeLogic() {
		gridview1.setAdapter(new Gridview1Adapter(_getApplicationList("app_name", "app_package")));
		gridview1.setNumColumns((int)5);
	}
	
	@Override
	public void onBackPressed() {
		gridview1.setAdapter(new Gridview1Adapter(_getApplicationList("app_name", "app_package")));
		gridview1.setNumColumns((int)5);
	}
	
	@Override
	public void onStart() {
		super.onStart();
		gridview1.setAdapter(new Gridview1Adapter(_getApplicationList("app_name", "app_package")));
		gridview1.setNumColumns((int)5);
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		gridview1.setAdapter(new Gridview1Adapter(_getApplicationList("app_name", "app_package")));
		gridview1.setNumColumns((int)5);
	}
	public void _setImageBitmap(final ImageView _imageview, final String _packagename) {
		new ApplicationInfo(this).setImageBitmap(_imageview,_packagename);
	}
	
	
	public ArrayList<HashMap<String, Object>> _getApplicationList(final String _app_name, final String _package_name) {
		return new ApplicationInfo(this).getApplicationList(_app_name,_package_name);
	}
	
	
	public void _library() {
	}
	
	public static class ApplicationInfo {
		
		private Context myContext;
		
		public ApplicationInfo(Context context) {
			    myContext = context;
		}
		
		public ApplicationInfo(Fragment fragment) {
			    myContext = fragment.getActivity();
		}
		
		public ApplicationInfo(DialogFragment fragment) {
			    myContext = fragment.getActivity();
		}
		
		public void setImageBitmap (final ImageView _imageview, final String _packagename) {
					try {
							    Drawable iconImage = myContext.getPackageManager().getApplicationIcon(_packagename);
							    _imageview.setImageDrawable(iconImage);
							    } catch (android.content.pm.PackageManager.NameNotFoundException e) {
							        
							    }
			}
			
			
			public ArrayList<HashMap<String, Object>> getApplicationList (final String _app_name, final String _package_name) {
					{
							android.content.pm.PackageManager pm = myContext.getPackageManager();
							     HashMap<String, Object> Map = new HashMap<>();
								 ArrayList<HashMap<String, Object>> map = new ArrayList<>();
							    Intent intent = new Intent(Intent.ACTION_MAIN, null);
							    intent.addCategory(Intent.CATEGORY_LAUNCHER);
							    List<android.content.pm.ResolveInfo> PackList = pm.queryIntentActivities(intent, android.content.pm.PackageManager.PERMISSION_GRANTED);
							    for (android.content.pm.ResolveInfo rInfo : PackList) {
									
									        String AppName = rInfo.activityInfo.applicationInfo.loadLabel(pm).toString();
									        String PackageName = rInfo.activityInfo.applicationInfo.packageName;
									Map = new HashMap<>();
									Map.put(_app_name, AppName);
									Map.put(_package_name, PackageName);
									map.add(Map);
									        }
							        return map;
							        }
			}
			
			public void openApp(String packageName) {
				    Intent launchIntent = myContext.getPackageManager().getLaunchIntentForPackage(packageName);
				    myContext.startActivity(launchIntent);
			}
			
			
		}
	{
	}
	
	
	public void _openApplication(final String _packageName) {
		new ApplicationInfo(this).openApp(_packageName);
	}
	
	public class Gridview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Gridview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.app_list, null);
			}
			
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			
			textview1.setText(_data.get((int)_position).get("app_name").toString());
			_setImageBitmap(imageview1, _data.get((int)_position).get("app_package").toString());
			imageview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					_openApplication(_data.get((int)_position).get("app_package").toString());
				}
			});
			imageview1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, Color.TRANSPARENT));
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}